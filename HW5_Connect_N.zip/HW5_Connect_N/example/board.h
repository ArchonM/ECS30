#ifndef BOARD_H
	#define BOARD_H
	void set_up(char*** board, int *turn);
	char** make_board(int num_rows, int num_cols);
	void print_board(char** board, int num_rows, int num_cols);
	
#endif
